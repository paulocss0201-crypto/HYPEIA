# Hype IA — Landing Page

Site estático (HTML/CSS/JS puro, um único arquivo `index.html`), pronto para deploy na Vercel.

## Como publicar na Vercel

### Opção 1 — Vercel CLI (mais rápido)
1. Instale a CLI, se ainda não tiver:
   ```
   npm i -g vercel
   ```
2. Dentro desta pasta, rode:
   ```
   vercel
   ```
3. Siga as perguntas no terminal (login, nome do projeto, etc). A Vercel detecta automaticamente que é um projeto estático — não precisa de build command.
4. Para publicar em produção:
   ```
   vercel --prod
   ```

### Opção 2 — Painel da Vercel (sem terminal)
1. Acesse https://vercel.com e faça login (dá pra usar GitHub, GitLab ou e-mail).
2. Clique em **Add New → Project**.
3. Se preferir sem GitHub: arraste esta pasta inteira na área de upload ("Deploy manually" / drag and drop).
4. Se preferir com GitHub: suba esta pasta como um repositório e importe o repositório na Vercel.
5. Confirme — não é necessário configurar build command nem output directory, o `index.html` já está na raiz.
6. Clique em **Deploy** e pronto, a Vercel gera a URL automaticamente (ex: `hype-ia.vercel.app`).

## Domínio próprio
Depois do primeiro deploy, em **Project Settings → Domains** você pode adicionar o domínio da Hype IA (ex: `hypeia.com.br`) e seguir as instruções de DNS que a Vercel mostra.

## Arquivos
- `index.html` — a landing page completa (HTML, CSS e JS em um único arquivo).
- `vercel.json` — configuração básica de rotas/URLs limpas.
- `package.json` — metadados do projeto (não é necessário rodar `npm install`, não há dependências).
